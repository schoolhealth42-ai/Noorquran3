/* نور القرآن — يجعل التطبيق يفتح بدون إنترنت ويحفظ النصوص والتفاسير بعد أول تحميل */
const VERSION = 'noor-1.4';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icons/icon-180.png', './icons/icon-192.png', './icons/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION && k !== 'noor-data' && k !== 'noor-fonts').map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

const isData = u => /api\.quran\.com|api\.alquran\.cloud|mp3quran\.net\/api|cdn\.jsdelivr\.net\/gh\/(fawazahmed0|spa5k)|raw\.githubusercontent\.com/.test(u);
const isFont = u => /fonts\.googleapis\.com|fonts\.gstatic\.com|\.woff2?($|\?)|\.ttf($|\?)/.test(u);

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || req.headers.has('range')) return;          // الصوت يمر مباشرة
  const u = req.url;
  if (/\.mp3($|\?)/.test(u)) return;
  // واجهة التطبيق: من الذاكرة أولًا مع تحديث في الخلفية
  if (req.mode === 'navigate' || u.startsWith(self.registration.scope)) {
    e.respondWith(caches.open(VERSION).then(async c => {
      const hit = await c.match(req, { ignoreSearch: true });
      const net = fetch(req).then(r => { if (r.ok) c.put(req, r.clone()); return r; }).catch(() => hit);
      return hit || net;
    }));
    return;
  }
  // الخطوط: من الذاكرة أولًا
  if (isFont(u)) {
    e.respondWith(caches.open('noor-fonts').then(async c => (await c.match(req)) || fetch(req).then(r => { if (r.ok || r.type === 'opaque') c.put(req, r.clone()); return r; })));
    return;
  }
  // البيانات (النصوص، التفاسير، القراء): من الإنترنت أولًا ثم المحفوظ
  if (isData(u)) {
    e.respondWith(caches.open('noor-data').then(c => fetch(req).then(r => { if (r.ok) c.put(req, r.clone()); return r; }).catch(async () => (await c.match(req)) || Response.error())));
  }
});
