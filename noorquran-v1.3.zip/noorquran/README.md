# نور القرآن — الإصدار 1.3 (مشروع Android Studio)

## طريقة الفتح والبناء
1. فك الضغط عن الملف.
2. في Android Studio: File ← Open ← اختر مجلد `noorquran` ← OK، وانتظر انتهاء المزامنة (Sync).
3. ☰ ← Build ← Generate App Bundles or APKs ← Generate APKs.
4. الملف الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## أو بدون Android Studio (عبر GitHub)
ارفع محتويات المجلد إلى مستودع جديد على GitHub ← تبويب Actions ← بعد انتهاء البناء حمّل `NoorQuran-APK`.

## الملفات المهمة
- الواجهة كاملة: `app/src/main/assets/index.html`
- الكود الأصلي (الصوت، التنزيل، التسميع): `app/src/main/java/com/example/noorquran/MainActivity.java`
- الأذونات: `app/src/main/AndroidManifest.xml`
- الاسم: `app/src/main/res/values/strings.xml`
- الأيقونة: `app/src/main/res/drawable/ic_launcher_foreground.xml`

## ملاحظة
اسم الحزمة `com.example.noorquran` مناسب للاستخدام الشخصي. قبل النشر في Google Play غيّره (مثل com.yourname.noorquran) وأنشئ مفتاح توقيع خاص.
