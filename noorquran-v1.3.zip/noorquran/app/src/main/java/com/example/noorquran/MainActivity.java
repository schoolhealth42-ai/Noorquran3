package com.example.noorquran;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.net.Uri;
import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private WebView web;
    private FrameLayout root;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private final ExecutorService dlExec = Executors.newSingleThreadExecutor();
    private final Map<String, Boolean> dlCancel = new ConcurrentHashMap<>();
    private volatile float insetTop = 0, insetBottom = 0;
    private volatile boolean hideNav = true, hideStatus = false;
    private SpeechRecognizer sr;
    private volatile boolean asrWanted = false;
    private long lastLevel = 0;
    private static final int REQ_MIC = 77;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tts", MODE_PRIVATE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#062A1F"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0B3D2E"));
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // الواجهة تمتد خلف أشرطة النظام، ونرسل مقاساتها للصفحة لتترك لها مساحة
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        SharedPreferences ui = getSharedPreferences("ui", MODE_PRIVATE);
        hideNav = ui.getBoolean("hideNav", true);
        hideStatus = ui.getBoolean("hideStatus", false);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets s = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            float d = getResources().getDisplayMetrics().density;
            insetTop = s.top / d;
            insetBottom = s.bottom / d;
            v.setPadding(s.left, 0, s.right, 0);
            js("window.setInsets && setInsets(" + insetTop + "," + insetBottom + ")");
            return WindowInsetsCompat.CONSUMED;
        });
        applySystemBars();

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        ws.setTextZoom(100);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        // زر الرجوع يمر على الواجهة أولًا
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                web.evaluateJavascript("window.handleBack ? handleBack() : false", r -> {
                    if (!"true".equals(r)) moveTaskToBack(true);
                });
            }
        });

        String eng = prefs.getString("engine", null);
        tts = (eng == null || eng.isEmpty()) ? new TextToSpeech(this, this) : new TextToSpeech(this, this, eng);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) return;
        int r = tts.setLanguage(new Locale("ar"));
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
        String vName = prefs.getString("voice", null);
        if (vName != null) {
            try {
                for (Voice v : tts.getVoices()) if (v.getName().equals(vName)) { tts.setVoice(v); break; }
            } catch (Exception ignored) { }
        }
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { js("window.onTts && onTts('start'," + JSONObject.quote(id) + ")"); }
            @Override public void onDone(String id) { js("window.onTts && onTts('done'," + JSONObject.quote(id) + ")"); }
            @Override public void onError(String id) { js("window.onTts && onTts('error'," + JSONObject.quote(id) + ")"); }
        });
        js("window.onTtsReady && onTtsReady()");
    }

    private void applySystemBars() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        c.setAppearanceLightStatusBars(false);
        c.setAppearanceLightNavigationBars(false);
        if (hideNav) c.hide(WindowInsetsCompat.Type.navigationBars()); else c.show(WindowInsetsCompat.Type.navigationBars());
        if (hideStatus) c.hide(WindowInsetsCompat.Type.statusBars()); else c.show(WindowInsetsCompat.Type.statusBars());
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applySystemBars();
    }

    /** مجلد حفظ التلاوات المنزّلة */
    private File audioBase() {
        File ext = getExternalFilesDir(null);
        File b = new File(ext != null ? ext : getFilesDir(), "audio");
        if (!b.exists()) b.mkdirs();
        return b;
    }

    private File safeFile(String rel) {
        if (rel == null || rel.contains("..")) return null;
        return new File(audioBase(), rel);
    }

    private static long dirBytes(File f) {
        if (f.isFile()) return f.length();
        long t = 0; File[] c = f.listFiles();
        if (c != null) for (File x : c) t += dirBytes(x);
        return t;
    }

    private static int dirCount(File f) {
        if (f.isFile()) return f.getName().endsWith(".mp3") ? 1 : 0;
        int t = 0; File[] c = f.listFiles();
        if (c != null) for (File x : c) t += dirCount(x);
        return t;
    }

    private boolean fetchTo(String url, File out) {
        HttpURLConnection c = null;
        File tmp = new File(out.getPath() + ".part");
        try {
            out.getParentFile().mkdirs();
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "NoorQuran/1.2 Android");
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) return false;
            try (InputStream in = c.getInputStream(); FileOutputStream o = new FileOutputStream(tmp)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            if (tmp.length() < 512) { tmp.delete(); return false; }
            return tmp.renameTo(out);
        } catch (Exception e) {
            tmp.delete();
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /* ================= التعرّف على الكلام (للتسميع) ================= */
    private void startAsr() {
        asrWanted = true;
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { js("window.onAsr && onAsr('ready','')"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rms) {
                    long now = System.currentTimeMillis();
                    if (now - lastLevel > 120) { lastLevel = now; js("window.onAsr && onAsr('level','" + rms + "')"); }
                }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int code) {
                    boolean soft = code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            || code == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || code == SpeechRecognizer.ERROR_CLIENT;
                    if (asrWanted && soft) { restartAsr(code == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 600 : 150); return; }
                    if (asrWanted) js("window.onAsr && onAsr('error','" + code + "')");
                    asrWanted = false;
                }
                @Override public void onResults(Bundle b) {
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) js("window.onAsr && onAsr('final'," + JSONObject.quote(r.get(0)) + ")");
                    if (asrWanted) restartAsr(100);
                }
                @Override public void onPartialResults(Bundle b) {
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) js("window.onAsr && onAsr('partial'," + JSONObject.quote(r.get(0)) + ")");
                }
                @Override public void onEvent(int t, Bundle b) { }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
        try { sr.startListening(i); js("window.onAsr && onAsr('start','')"); }
        catch (Exception e) { js("window.onAsr && onAsr('error','start')"); }
    }

    private void restartAsr(long delay) {
        main.postDelayed(() -> {
            if (!asrWanted || sr == null) return;
            try { sr.cancel(); } catch (Exception ignored) { }
            startAsr();
        }, delay);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_MIC) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAsr();
        else js("window.onAsr && onAsr('denied','')");
    }

    private void js(final String code) {
        main.post(() -> web.evaluateJavascript(code, null));
    }

    private File cacheFile(String url) {
        String h;
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(url.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            h = sb.toString();
        } catch (Exception e) { h = String.valueOf(url.hashCode()); }
        File dir = new File(getFilesDir(), "http");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, h);
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    private static void deleteDir(File f) {
        if (f.isDirectory()) { File[] c = f.listFiles(); if (c != null) for (File x : c) deleteDir(x); }
        f.delete();
    }

    /** الجسر بين الواجهة (index.html) والنظام */
    public class Bridge {

        /** جلب البيانات من الإنترنت مع حفظها للاستخدام بدون اتصال */
        @JavascriptInterface
        public void httpGet(final String url, final String cb) {
            io.execute(() -> {
                File f = cacheFile(url);
                String body = null;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setRequestProperty("User-Agent", "NoorQuran/1.1 Android");
                    c.setRequestProperty("Accept", "application/json");
                    int code = c.getResponseCode();
                    if (code >= 200 && code < 300) {
                        body = readAll(c.getInputStream());
                        try (FileOutputStream o = new FileOutputStream(f)) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                    }
                    c.disconnect();
                } catch (Exception ignored) { }
                if (body == null && f.exists()) {
                    try { body = readAll(new FileInputStream(f)); } catch (Exception ignored) { }
                }
                String payload = body != null ? JSONObject.quote(body) : "null";
                js("window.__httpCb(" + JSONObject.quote(cb) + "," + payload + ")");
            });
        }

        @JavascriptInterface
        public void clearCache() {
            deleteDir(new File(getFilesDir(), "http"));
            main.post(() -> web.clearCache(true));
        }

        @JavascriptInterface
        public boolean ttsAvailable() { return ttsReady; }

        @JavascriptInterface
        public void speak(String text, String id, float rate, float pitch) {
            if (tts == null) return;
            tts.setSpeechRate(rate);
            tts.setPitch(pitch);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
        }

        @JavascriptInterface
        public void stopSpeak() { if (tts != null) tts.stop(); }

        /** الأصوات العربية المتاحة، الأعلى جودة أولًا */
        @JavascriptInterface
        public String getVoices() {
            JSONArray arr = new JSONArray();
            try {
                Set<Voice> all = tts.getVoices();
                List<Voice> ar = new ArrayList<>();
                if (all != null) for (Voice v : all) if ("ar".equals(v.getLocale().getLanguage())) ar.add(v);
                ar.sort((a, b) -> {
                    if (a.getQuality() != b.getQuality()) return b.getQuality() - a.getQuality();
                    return Boolean.compare(a.isNetworkConnectionRequired(), b.isNetworkConnectionRequired());
                });
                for (Voice v : ar) {
                    boolean notInstalled = v.getFeatures() != null
                            && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
                    JSONObject o = new JSONObject();
                    o.put("name", v.getName());
                    o.put("locale", v.getLocale().toString());
                    o.put("quality", v.getQuality());
                    o.put("network", v.isNetworkConnectionRequired());
                    o.put("installed", !notInstalled);
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public String currentVoice() {
            try { Voice v = tts.getVoice(); return v != null ? v.getName() : ""; } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void setVoice(final String name) {
            main.post(() -> {
                prefs.edit().putString("voice", name).apply();
                try {
                    for (Voice v : tts.getVoices()) if (v.getName().equals(name)) { tts.setVoice(v); break; }
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public String getEngines() {
            JSONObject res = new JSONObject();
            try {
                JSONArray arr = new JSONArray();
                for (TextToSpeech.EngineInfo e : tts.getEngines()) {
                    arr.put(new JSONObject().put("name", e.name).put("label", e.label));
                }
                res.put("current", tts.getDefaultEngine());
                res.put("list", arr);
            } catch (Exception ignored) { }
            return res.toString();
        }

        @JavascriptInterface
        public void setEngine(final String name) {
            main.post(() -> {
                prefs.edit().putString("engine", name).remove("voice").apply();
                if (tts != null) tts.shutdown();
                ttsReady = false;
                tts = new TextToSpeech(MainActivity.this, MainActivity.this, name);
            });
        }

        @JavascriptInterface
        public void installVoices() {
            main.post(() -> {
                try { startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void openTtsSettings() {
            main.post(() -> {
                try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
                catch (Exception e) { installVoices(); }
            });
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null) return;
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            main.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            main.post(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "مشاركة"));
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            main.post(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void setBars(final String color) {
            main.post(() -> {
                try { root.setBackgroundColor(Color.parseColor(color)); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void exitApp() { main.post(() -> moveTaskToBack(true)); }

        /* ---------- التسميع ---------- */
        @JavascriptInterface
        public boolean asrAvailable() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }

        @JavascriptInterface
        public void asrStart() {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    return;
                }
                startAsr();
            });
        }

        @JavascriptInterface
        public void asrStop() {
            main.post(() -> {
                asrWanted = false;
                if (sr != null) { try { sr.stopListening(); sr.cancel(); } catch (Exception ignored) { } }
                js("window.onAsr && onAsr('end','')");
            });
        }

        /* ---------- أشرطة النظام ---------- */
        @JavascriptInterface
        public String getInsets() { return "{\"t\":" + insetTop + ",\"b\":" + insetBottom + "}"; }

        @JavascriptInterface
        public void setSystemBars(final boolean nav, final boolean status) {
            hideNav = nav; hideStatus = status;
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("hideNav", nav).putBoolean("hideStatus", status).apply();
            main.post(MainActivity.this::applySystemBars);
        }

        /* ---------- التنزيلات ---------- */
        @JavascriptInterface
        public void startDownload(final String id, final String json) {
            dlCancel.put(id, false);
            dlExec.execute(() -> {
                int done = 0, failed = 0, total = 0;
                long last = 0;
                try {
                    JSONArray arr = new JSONArray(json);
                    total = arr.length();
                    for (int i = 0; i < total; i++) {
                        if (Boolean.TRUE.equals(dlCancel.get(id))) {
                            js("window.onDl && onDl('" + id + "'," + done + "," + total + "," + failed + ",'cancel')");
                            dlCancel.remove(id);
                            return;
                        }
                        JSONObject it = arr.getJSONObject(i);
                        File f = safeFile(it.getString("rel"));
                        if (f != null && !(f.exists() && f.length() > 0)) {
                            boolean ok = fetchTo(it.getString("url"), f);
                            if (!ok) ok = fetchTo(it.getString("url"), f);
                            if (!ok) failed++;
                        }
                        done++;
                        long now = System.currentTimeMillis();
                        if (now - last > 400 || done == total) {
                            last = now;
                            js("window.onDl && onDl('" + id + "'," + done + "," + total + "," + failed + ",'run')");
                        }
                    }
                } catch (Exception ignored) { }
                dlCancel.remove(id);
                js("window.onDl && onDl('" + id + "'," + done + "," + total + "," + failed + ",'done')");
            });
        }

        @JavascriptInterface
        public void cancelDownload(String id) { dlCancel.put(id, true); }

        /** رابط الملف المحلي إن كان منزّلًا، وإلا نص فارغ */
        @JavascriptInterface
        public String fileUrl(String rel) {
            File f = safeFile(rel);
            return (f != null && f.exists() && f.length() > 0) ? Uri.fromFile(f).toString() : "";
        }

        @JavascriptInterface
        public String listFiles(String dir) {
            JSONArray arr = new JSONArray();
            File d = safeFile(dir);
            if (d != null) { String[] n = d.list(); if (n != null) for (String x : n) if (x.endsWith(".mp3")) arr.put(x); }
            return arr.toString();
        }

        @JavascriptInterface
        public String listDirs() {
            JSONArray arr = new JSONArray();
            for (String t : new String[]{"ea", "mq"}) {
                File[] ds = new File(audioBase(), t).listFiles();
                if (ds == null) continue;
                for (File d : ds) {
                    int c = dirCount(d);
                    if (c == 0) continue;
                    try { arr.put(new JSONObject().put("dir", t + "/" + d.getName()).put("files", c).put("bytes", dirBytes(d))); }
                    catch (Exception ignored) { }
                }
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void deletePath(String rel) {
            File f = safeFile(rel);
            if (f != null && !rel.isEmpty()) deleteDir(f);
        }

        @JavascriptInterface
        public String freeSpace() { return String.valueOf(audioBase().getUsableSpace()); }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        asrWanted = false;
        if (sr != null) sr.destroy();
        io.shutdownNow();
        dlExec.shutdownNow();
        web.destroy();
        super.onDestroy();
    }
}
