plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.noorquran"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.noorquran"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // موقّع بمفتاح debug ليُثبَّت مباشرة. استخدم مفتاحك الخاص قبل النشر في Google Play.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.activity:activity:1.9.3")
}
